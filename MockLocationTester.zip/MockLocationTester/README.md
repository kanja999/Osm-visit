# Mock Location Tester

Aplikasi Android untuk **menguji aplikasi berbasis lokasi**. Pilih titik atau rute di peta
OpenStreetMap (via [osmdroid](https://github.com/osmdroid/osmdroid)), lalu aplikasi
mengirim koordinat itu sebagai lokasi GPS uji.

## Cara pakai
1. Install APK (lihat tab **Actions** > build terbaru > Artifacts).
2. Aktifkan **Opsi Pengembang** di HP.
3. Buka **Opsi Pengembang > Pilih aplikasi lokasi palsu** > pilih *Mock Location Tester*.
4. **Mode titik** (default): ketuk peta untuk memilih satu titik, tekan **Mulai**.
5. **Mode rute**: nyalakan *Mode rute*, ketuk beberapa titik berurutan, atur kecepatan (1-120 km/j) dengan slider, lalu tekan **Mulai**. Centang *Ulangi* agar rute berputar terus.
6. **Berhenti** menghentikan pengiriman lokasi; **Hapus** mengosongkan titik/rute.

## Build
- **GitHub Actions**: push ke branch `main`, APK debug otomatis dibuat.
- **Lokal**: buka folder ini di Android Studio, atau jalankan `gradle assembleDebug`
  (Gradle 8.7+, JDK 17).

## Deploy ke GitHub
```bash
git init
git add .
git commit -m "Initial commit"
git branch -M main
git remote add origin https://github.com/USERNAME/MockLocationTester.git
git push -u origin main
```

## Catatan
- Hanya untuk pengujian dan pengembangan. Memalsukan lokasi untuk menipu layanan
  (absensi, game, transportasi online, dll.) melanggar ketentuan layanan mereka.
- Tile OpenStreetMap tunduk pada [Tile Usage Policy](https://operations.osmfoundation.org/policies/tiles/);
  jangan dipakai untuk trafik besar.
- Proyek ini belum menyertakan `gradle-wrapper`; di Android Studio wrapper dibuat
  otomatis saat sync, atau jalankan `gradle wrapper`.
