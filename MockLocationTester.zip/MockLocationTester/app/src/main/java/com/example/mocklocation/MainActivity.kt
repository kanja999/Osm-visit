package com.example.mocklocation

import android.graphics.Color
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Button
import android.widget.CheckBox
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.switchmaterial.SwitchMaterial
import org.osmdroid.config.Configuration
import org.osmdroid.events.MapEventsReceiver
import org.osmdroid.tileprovider.tilesource.TileSourceFactory
import org.osmdroid.util.GeoPoint
import org.osmdroid.views.MapView
import org.osmdroid.views.overlay.MapEventsOverlay
import org.osmdroid.views.overlay.Marker
import org.osmdroid.views.overlay.Overlay
import org.osmdroid.views.overlay.Polyline

class MainActivity : AppCompatActivity() {

    private lateinit var map: MapView
    private lateinit var status: TextView
    private lateinit var speedLabel: TextView
    private lateinit var swRoute: SwitchMaterial
    private lateinit var cbLoop: CheckBox
    private lateinit var mock: MockLocationHelper

    private val points = mutableListOf<GeoPoint>()
    private val drawn = mutableListOf<Overlay>()
    private var posMarker: Marker? = null

    private var running = false
    private var speedMps = 40 / 3.6
    private var seg = 0
    private var segDist = 0.0

    private val handler = Handler(Looper.getMainLooper())
    private val ticker = object : Runnable {
        override fun run() {
            if (!running) return
            tick()
            handler.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // osmdroid wajib punya user agent agar tile OpenStreetMap tidak diblokir.
        Configuration.getInstance().apply {
            load(applicationContext, getSharedPreferences("osmdroid", MODE_PRIVATE))
            userAgentValue = packageName
        }

        setContentView(R.layout.activity_main)
        mock = MockLocationHelper(this)
        status = findViewById(R.id.status)
        speedLabel = findViewById(R.id.speedLabel)
        swRoute = findViewById(R.id.swRoute)
        cbLoop = findViewById(R.id.cbLoop)

        map = findViewById<MapView>(R.id.map).apply {
            setTileSource(TileSourceFactory.MAPNIK)
            setMultiTouchControls(true)
            controller.setZoom(5.0)
            controller.setCenter(GeoPoint(-2.5, 118.0)) // Indonesia
        }

        map.overlays.add(MapEventsOverlay(object : MapEventsReceiver {
            override fun singleTapConfirmedHelper(p: GeoPoint): Boolean {
                onMapTap(p); return true
            }
            override fun longPressHelper(p: GeoPoint) = false
        }))

        findViewById<SeekBar>(R.id.seekSpeed).setOnSeekBarChangeListener(
            object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar, value: Int, fromUser: Boolean) {
                    val kmh = value + 1
                    speedMps = kmh / 3.6
                    speedLabel.text = "$kmh km/j"
                }
                override fun onStartTrackingTouch(sb: SeekBar) {}
                override fun onStopTrackingTouch(sb: SeekBar) {}
            })

        swRoute.setOnCheckedChangeListener { _, _ -> clearAll() }
        findViewById<Button>(R.id.btnApply).setOnClickListener { start() }
        findViewById<Button>(R.id.btnStop).setOnClickListener { stop() }
        findViewById<Button>(R.id.btnClear).setOnClickListener { clearAll() }
    }

    // ---- Peta ----

    private fun onMapTap(p: GeoPoint) {
        if (swRoute.isChecked) {
            points.add(p)
            if (running) resetProgress()
        } else {
            points.clear()
            points.add(p)
        }
        redraw()
        status.text = if (swRoute.isChecked) "Rute: ${points.size} titik"
        else "Dipilih: %.5f, %.5f".format(p.latitude, p.longitude)
    }

    private fun redraw() {
        map.overlays.removeAll(drawn.toSet())
        drawn.clear()
        if (points.size > 1) {
            val line = Polyline().apply {
                setPoints(points)
                outlinePaint.color = Color.BLUE
                outlinePaint.strokeWidth = 8f
            }
            drawn.add(line)
        }
        points.forEachIndexed { i, p ->
            drawn.add(Marker(map).apply {
                position = p
                title = "Titik ${i + 1}"
                setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM)
            })
        }
        map.overlays.addAll(drawn)
        map.invalidate()
    }

    private fun clearAll() {
        stop()
        points.clear()
        redraw()
        posMarker?.let { map.overlays.remove(it) }
        posMarker = null
        status.text = getString(R.string.hint)
    }

    // ---- Simulasi ----

    private fun resetProgress() { seg = 0; segDist = 0.0 }

    private fun start() {
        if (points.isEmpty()) {
            Toast.makeText(this, getString(R.string.hint), Toast.LENGTH_SHORT).show()
            return
        }
        try {
            mock.start()
        } catch (e: SecurityException) {
            Toast.makeText(
                this,
                "Pilih app ini di Opsi Pengembang > Pilih aplikasi lokasi palsu",
                Toast.LENGTH_LONG
            ).show()
            return
        }
        resetProgress()
        running = true
        handler.removeCallbacks(ticker)
        handler.post(ticker)
    }

    /** Maju sejauh kecepatan x 1 detik di sepanjang rute, lalu kirim lokasinya. */
    private fun tick() {
        if (points.isEmpty()) return
        if (points.size == 1) {
            send(points[0], 0f, 0f); return
        }

        var remaining = speedMps
        while (remaining > 0 && seg < points.size - 1) {
            val len = points[seg].distanceToAsDouble(points[seg + 1])
            val left = len - segDist
            if (remaining >= left) {
                remaining -= left; seg++; segDist = 0.0
            } else {
                segDist += remaining; remaining = 0.0
            }
        }

        if (seg >= points.size - 1) {
            send(points.last(), 0f, 0f)
            if (cbLoop.isChecked) resetProgress()
        } else {
            val a = points[seg]; val b = points[seg + 1]
            val len = a.distanceToAsDouble(b)
            val f = if (len > 0) segDist / len else 0.0
            val cur = GeoPoint(
                a.latitude + (b.latitude - a.latitude) * f,
                a.longitude + (b.longitude - a.longitude) * f
            )
            send(cur, a.bearingTo(b).toFloat(), speedMps.toFloat())
        }
    }

    private fun send(p: GeoPoint, bearing: Float, speed: Float) {
        mock.setLocation(p.latitude, p.longitude, 5f, bearing, speed)
        if (posMarker == null) {
            posMarker = Marker(map).apply {
                title = "Posisi uji"
                setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_CENTER)
            }
            map.overlays.add(posMarker)
        }
        posMarker!!.position = p
        map.invalidate()
        status.text = "Aktif: %.5f, %.5f  (%.0f km/j)".format(
            p.latitude, p.longitude, speed * 3.6
        )
    }

    private fun stop() {
        running = false
        handler.removeCallbacks(ticker)
        mock.stop()
        status.text = "Dihentikan"
    }

    override fun onResume() { super.onResume(); map.onResume() }
    override fun onPause() { super.onPause(); map.onPause() }
    override fun onDestroy() { stop(); super.onDestroy() }
}
