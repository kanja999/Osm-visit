package com.example.mocklocation

import android.content.Context
import android.location.Location
import android.location.LocationManager
import android.location.provider.ProviderProperties
import android.os.Build
import android.os.SystemClock

/** Mengirim lokasi uji lewat LocationManager test provider (khusus pengujian). */
class MockLocationHelper(context: Context) {

    private val lm = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
    private val provider = LocationManager.GPS_PROVIDER

    /** Melempar SecurityException jika app belum dipilih sebagai "aplikasi lokasi palsu". */
    fun start() {
        try { lm.removeTestProvider(provider) } catch (_: Exception) {}

        if (Build.VERSION.SDK_INT >= 31) {
            lm.addTestProvider(
                provider, false, false, false, false, true, true, true,
                ProviderProperties.POWER_USAGE_LOW, ProviderProperties.ACCURACY_FINE
            )
        } else {
            @Suppress("DEPRECATION")
            lm.addTestProvider(provider, false, false, false, false, true, true, true, 1, 1)
        }
        lm.setTestProviderEnabled(provider, true)
    }

    fun setLocation(
        lat: Double, lon: Double,
        accuracy: Float = 5f, bearing: Float = 0f, speed: Float = 0f
    ) {
        val loc = Location(provider).apply {
            latitude = lat
            longitude = lon
            altitude = 0.0
            this.accuracy = accuracy
            this.bearing = bearing
            this.speed = speed
            time = System.currentTimeMillis()
            elapsedRealtimeNanos = SystemClock.elapsedRealtimeNanos()
        }
        lm.setTestProviderLocation(provider, loc)
    }

    fun stop() {
        try {
            lm.setTestProviderEnabled(provider, false)
            lm.removeTestProvider(provider)
        } catch (_: Exception) {}
    }
}
